#pragma once
#include <iostream>

using namespace std;

class cNguoi
{
private:
	string sHoTen;
	int iNamSinh;
	string sCMND;
	string sDiaChi;
public:
	void Nhap();
	void Xuat();
};
