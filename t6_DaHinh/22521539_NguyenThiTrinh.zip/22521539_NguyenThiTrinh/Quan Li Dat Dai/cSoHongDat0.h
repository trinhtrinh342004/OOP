#pragma once
#include "cSoHong.h"
#include <iostream>

using namespace std;

class cSoHongDatO : public cSoHong
{
public:
	void Xuat();
	int getLoai();
};
