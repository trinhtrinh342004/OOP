#pragma once
#include "GiaSuc.h"

class De : public GiaSuc
{
public:
	void Keu();
	int SinhCon();
	int ChoSua();
};