﻿#pragma once
#include <iostream>

class GiaSuc
{
public:
	void Keu(); // cách kêu 
	int SinhCon();  // số con sinh được 
	int ChoSua(); // lượng sữa thu được 
};