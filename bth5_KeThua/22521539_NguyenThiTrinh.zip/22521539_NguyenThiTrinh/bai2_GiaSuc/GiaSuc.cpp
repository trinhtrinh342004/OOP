#include "GiaSuc.h"

void GiaSuc::Keu(){}

int GiaSuc::SinhCon()
{
	return 0;
}

int GiaSuc::ChoSua()
{
	return 0;
}