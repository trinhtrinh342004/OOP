#pragma once
#include "GiaSuc.h"

class Bo : public GiaSuc
{
public:
	void Keu();
	int SinhCon();
	int ChoSua();
};