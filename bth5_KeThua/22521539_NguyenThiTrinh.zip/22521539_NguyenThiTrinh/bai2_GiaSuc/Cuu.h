#pragma once
#include "GiaSuc.h"

class Cuu: public GiaSuc
{
public: 
	void Keu();
	int SinhCon();
	int ChoSua();
};